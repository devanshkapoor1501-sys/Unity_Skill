"""Evidence-based native-binding repair; no arbitrary patches or source execution."""

from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from collections import Counter
from dataclasses import replace
from pathlib import Path
from typing import Any
from uuid import uuid4

from polyforge.contracts.manifest import load_manifest
from polyforge.contracts.results import ErrorKind, Result, failure
from polyforge.contracts.validation import InputError, canonical_digest, load_json
from polyforge.runner.locks import unity_project_lock
from polyforge.runner.state import atomic_json
from polyforge.security.paths import WorkspacePolicy
from polyforge.unity.bootstrap import check_project_idle
from polyforge.unity.bridge import configuration, launch, unity_tool
from polyforge.unity.evidence import reconcile_report
from polyforge.unity.transactions import ManagedTransaction

CATEGORIES = {"scale", "axis", "pivot", "material", "socket", "component", "binding", "collider"}


def verify_source_hashes(policy: WorkspacePolicy, request: dict[str, Any]) -> None:
    for asset in request["assets"]:
        path = policy.path("UnityProject/" + asset["fbx_path"])
        actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
        if actual != asset["sha256"]:
            raise InputError(
                f"Source identity mismatch for {asset['id']}: expected "
                f"{asset['sha256']}, observed {actual}; rebuild S3/S4",
                kind=ErrorKind.CONTRACT_FAILURE,
                code="PF-UNITY-SOURCE-IDENTITY",
            )


def symptom(issue: dict[str, Any]) -> str:
    return canonical_digest(
        {key: issue[key] for key in ("category", "asset_id", "expected", "actual")}
    )


def resolve_plan(policy: WorkspacePolicy, plan: dict[str, Any], request: dict[str, Any]) -> str:
    validate_plan(plan, request)
    evidence = load_json(policy.path(".polyforge/unity-issues.json"))
    match = next((i for i in evidence["issues"] if i["issue_id"] == plan["issue_id"]), None)
    if (
        evidence["input_digest"] != request["input_digest"]
        or match is None
        or match["category"] != plan["category"]
        or match["asset_id"] != plan["asset_id"]
    ):
        raise InputError("Repair plan does not match recorded diagnostic evidence")
    return canonical_digest({"input_digest": request["input_digest"], "symptom": symptom(match)})


def scoped_verification(baseline: dict[str, Any], after: dict[str, Any], asset_id: str) -> bool:
    allowed = Counter(symptom(i) for i in baseline["issues"] if i["asset_id"] != asset_id)
    actual = Counter(symptom(i) for i in after["issues"])
    return not any(i["asset_id"] == asset_id for i in after["issues"]) and actual <= allowed


def equivalent_bindings(before: Any, after: Any) -> bool:
    """Static restore equivalence: 0.1mm / 1ppm for numbers, exact identities."""
    if type(before) in {int, float} and type(after) in {int, float}:
        return math.isclose(before, after, abs_tol=0.0001, rel_tol=1e-6)
    if isinstance(before, dict):
        return (
            isinstance(after, dict)
            and before.keys() == after.keys()
            and all(equivalent_bindings(v, after[k]) for k, v in before.items())
        )
    if isinstance(before, list):
        return (
            isinstance(after, list)
            and len(before) == len(after)
            and all(equivalent_bindings(a, b) for a, b in zip(before, after, strict=True))
        )
    return bool(before == after)


def current_request(policy: WorkspacePolicy) -> dict[str, Any]:
    check_project_idle(policy)
    if not policy.path("UnityProject/.polyforge-project.json").is_file():
        raise InputError("A managed S4 project is required")
    request: dict[str, Any] = load_json(policy.path(".polyforge/unity-request.json"))
    if request["input_digest"] != load_manifest(policy.path("game_manifest.json")).input_digest:
        raise InputError("Manifest/source identity changed; rebuild S4 before reconciliation")
    verify_source_hashes(policy, request)
    return request


def reconcile_workspace(workspace: Path) -> Result:
    policy = WorkspacePolicy(workspace)
    request = current_request(policy)
    config = configuration(policy)
    executable = unity_tool(config)
    run_id = "reconcile-" + uuid4().hex[:16]
    relative = "runs/" + run_id
    with unity_project_lock(policy, policy.path("UnityProject")):
        request_path = atomic_json(policy, relative + "/request.json", request)
        path = policy.path(relative + "/bindings.json")
        launch(
            policy,
            executable,
            config,
            relative + "/observe",
            "reconcile",
            request=request_path,
            output=path,
            allow_contract_failure=True,
        )
        report = reconcile_report(request, load_json(path))
        for issue in report["issues"]:
            issue["issue_id"] = "ISSUE-" + canonical_digest(issue)[:12]
        atomic_json(policy, relative + "/reconcile.json", report)
        atomic_json(
            policy,
            ".polyforge/unity-issues.json",
            {
                "input_digest": request["input_digest"],
                "evidence_dir": relative,
                "issues": report["issues"],
            },
        )
    return Result(
        status=report["status"],
        exit_code=0 if report["status"] == "PASS" else 6,
        error_code=None if report["status"] == "PASS" else "PF-UNITY-RECONCILE",
        run_id=run_id,
        input_digest=request["input_digest"],
        data=report,
        evidence_paths=[relative + "/bindings.json", relative + "/reconcile.json"],
    )


def diagnose(workspace: Path, evidence_dir: str) -> Result:
    policy = WorkspacePolicy(workspace)
    request = current_request(policy)
    directory = policy.path(evidence_dir)
    if directory.parent != policy.path("runs"):
        raise InputError("Diagnosis requires one managed run evidence directory")
    raw = load_json(policy.path(directory / "bindings.json"))
    report = reconcile_report(request, raw)
    issues = [
        {
            **issue,
            "issue_id": "ISSUE-" + canonical_digest(issue)[:12],
            "repair_supported": issue["category"] in CATEGORIES,
        }
        for issue in report["issues"]
    ]
    from polyforge.repairs.diagnostics import diagnose_evidence

    codes = {
        "binding": "PF-GUID-MISMATCH",
        "scale": "PF-FBX-AXES",
        "axis": "PF-FBX-AXES",
        "material": "PF-MATERIAL-SWAPPED",
        "component": "PF-COMPONENT-MISSING",
    }
    observed_path = directory.relative_to(policy.root).as_posix() + "/bindings.json"
    forensics = [
        diagnose_evidence(
            {
                "schema_version": "1.0.0",
                "input_digest": request["input_digest"],
                "producer_id": "unity_integration",
                "tool": {"name": "unity", "version": raw["unity_version"]},
                "structured": {"status": "FAIL", "code": codes.get(issue["category"], "UNKNOWN")},
                "log": json.dumps(issue, sort_keys=True),
                "affected_ids": [issue["asset_id"]],
                "artifacts": [
                    {
                        "id": "native_bindings",
                        "path": observed_path,
                        "sha256": hashlib.sha256(
                            policy.path(observed_path).read_bytes()
                        ).hexdigest(),
                    }
                ],
            }
        )
        for issue in issues
        if isinstance(issue.get("asset_id"), str)
        and re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,63}", issue["asset_id"])
    ]
    return Result(
        input_digest=request["input_digest"],
        data={
            "diagnosis_status": report["status"],
            "issues": issues,
            "forensics": forensics,
            "evidence_dir": directory.relative_to(policy.root).as_posix(),
        },
    )


def validate_plan(plan: dict[str, Any], request: dict[str, Any]) -> None:
    fields = {"schema_version", "input_digest", "issue_id", "category", "asset_id", "operation"}
    if (
        not isinstance(plan, dict)
        or set(plan) != fields
        or any(not isinstance(v, str) for v in plan.values())
        or plan["schema_version"] != "1.0.0"
        or plan["input_digest"] != request["input_digest"]
        or plan["category"] not in CATEGORIES
        or plan["asset_id"] not in {a["id"] for a in request["assets"]}
        or plan["operation"] != "rebuild_native_binding"
        or not isinstance(plan["issue_id"], str)
        or not re.fullmatch(r"ISSUE-[a-zA-Z0-9]+", plan["issue_id"])
    ):
        raise InputError("Repair plan is stale, unbounded or outside native-binding scope")


def repair_plan(workspace: Path, issue_id: str) -> Result:
    policy = WorkspacePolicy(workspace)
    request = current_request(policy)
    evidence = load_json(policy.path(".polyforge/unity-issues.json"))
    if evidence["input_digest"] != request["input_digest"]:
        raise InputError("Diagnosis belongs to a different manifest")
    issue = next((i for i in evidence["issues"] if i["issue_id"] == issue_id), None)
    if issue is None:
        raise InputError("Unknown issue ID; reconcile the managed project first")
    plan = {
        "schema_version": "1.0.0",
        "input_digest": request["input_digest"],
        "issue_id": issue_id,
        "category": issue["category"],
        "asset_id": issue["asset_id"],
        "operation": "rebuild_native_binding",
    }
    validate_plan(plan, request)
    identifier = issue["asset_id"]
    return Result(
        input_digest=request["input_digest"],
        data={
            "dry_run": True,
            "plan": plan,
            "patch_preview": {
                "operation": "Restore native bindings from frozen source; rebuild dependent scenes",
                "asset_id": identifier,
                "geometry_generation": "NOT_RUN",
                "managed_prefix": "UnityProject/Assets/PolyForgeGenerated",
            },
            "verification": "native reconciliation; automatic rollback on failed verification",
            "cross_application_recovery": "Required native reimport and source/regression proof",
        },
    )


def repair_apply(workspace: Path, plan_path: str, *, forensic_run: str | None = None) -> Result:
    policy = WorkspacePolicy(workspace)
    plan = load_json(policy.path(plan_path))
    if "diagnosis" in plan:
        from polyforge.repairs.execution import apply_forensic

        return apply_forensic(workspace, plan)
    request = current_request(policy)
    key = resolve_plan(policy, plan, request)
    config = configuration(policy)
    executable = unity_tool(config)
    tx_id = "tx-" + uuid4().hex[:16]
    relative = f"transactions/{tx_id}"
    with unity_project_lock(policy, policy.path("UnityProject")):
        attempts_path = policy.path(".polyforge/repair-attempts.json")
        attempts = load_json(attempts_path) if attempts_path.is_file() else {}
        if attempts.get(key, 0) >= 2:
            return failure(
                ErrorKind.RETRY_EXHAUSTED,
                "PF-REPAIR-ATTEMPTS",
                "Two proposals already attempted for this symptom",
            )
        from polyforge.unity.recovery import observe_state, rollback_locked, source_dependencies
        from polyforge.unity.transactions import inventory

        prestate = observe_state(policy, f"runs/repair-baseline-{tx_id}")
        baseline_raw = prestate["bindings"]
        baseline = reconcile_report(request, baseline_raw)
        if not any(
            i["asset_id"] == plan["asset_id"] and i["category"] == plan["category"]
            for i in baseline["issues"]
        ):
            raise InputError("Issue is no longer present; reconcile and replan")
        tx = ManagedTransaction.create(policy, tx_id, dependencies=source_dependencies(policy))
        tx.record(
            "BASELINE",
            observed=baseline_raw,
            reconciliation=baseline,
            prestate=prestate,
            forensic_run=forensic_run,
            proof_scope="NATIVE_REIMPORT_AND_REGRESSION",
        )
        if forensic_run is not None:
            intent_path = "runs/" + forensic_run + "/intent.json"
            intent = load_json(policy.path(intent_path))
            atomic_json(policy, intent_path, {**intent, "transaction_id": tx_id})
        attempts[key] = attempts.get(key, 0) + 1
        atomic_json(policy, attempts_path, attempts)
        affected = copy.deepcopy(request)
        affected["rebuild_asset_ids"] = [plan["asset_id"]]
        apply_request = atomic_json(policy, relative + "/request.json", affected)
        tx.record("APPLYING", plan=plan)
        try:
            output = policy.path(relative + "/after.json")
            launch(
                policy,
                executable,
                config,
                relative + "/apply",
                "build",
                request=apply_request,
                output=output,
                allow_contract_failure=True,
            )
            tx.record("APPLIED")
            current = inventory(policy, tx.read().get("dependencies", []))
            original = tx.read()["original"]
            diff = {
                "added": sorted(current.keys() - original.keys()),
                "removed": sorted(original.keys() - current.keys()),
                "modified": sorted(
                    n for n in original.keys() & current.keys() if original[n] != current[n]
                ),
            }
            tx.record("VERIFYING", changed_paths=diff)
            report = reconcile_report(request, load_json(output))
            if not scoped_verification(baseline, report, plan["asset_id"]):
                raise InputError(json.dumps(report["issues"]), kind=ErrorKind.CONTRACT_FAILURE)
            after_state = observe_state(
                policy, relative + "/verification", profile_inputs=prestate["profile_inputs"]
            )
            before_regression = prestate["regressions"]
            after_regression = after_state["regressions"]
            if set(before_regression) != set(after_regression):
                raise InputError("Repair changed the required regression profile set")
            for profile, previous in before_regression.items():
                if profile == "arena":
                    if any(
                        v == "PASS" and after_regression[profile]["scenarios"].get(k) != "PASS"
                        for k, v in previous["scenarios"].items()
                    ):
                        raise InputError("Repair regressed an independent original gameplay check")
                elif previous != after_regression[profile]:
                    raise InputError("Repair regressed native animation/sprite checks")
            tx.record(
                "COMMITTED",
                verification=report,
                after_state=after_state,
                committed_inventory=inventory(policy, tx.read().get("dependencies", [])),
            )
            return Result(
                rollback_id=tx_id,
                data={
                    "repair_status": "COMMITTED",
                    "plan": plan,
                    "remaining_issues": report["issues"],
                },
                evidence_paths=[relative + "/journal.json", relative + "/after.json"],
            )
        except (InputError, OSError, KeyboardInterrupt) as exc:
            rolled_back = rollback_locked(policy, tx)
            if rolled_back.status != "PASS":
                return rolled_back
            # Keep Phase 5's visible faulty-baseline reconciliation alongside the new proof.
            tx.record(
                "ROLLED_BACK",
                verification=reconcile_report(request, tx.read()["recovery"]["bindings"]),
            )
            return replace(
                failure(
                    ErrorKind.INTERRUPTED
                    if isinstance(exc, KeyboardInterrupt)
                    else ErrorKind.CONTRACT_FAILURE,
                    "PF-REPAIR-ROLLED-BACK",
                    str(exc),
                ),
                rollback_id=tx_id,
                evidence_paths=[relative + "/journal.json"],
            )
