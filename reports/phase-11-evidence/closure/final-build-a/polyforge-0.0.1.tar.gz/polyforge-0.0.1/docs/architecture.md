# Architecture and capability-first decision

PolyForge provides executable reusable infrastructure, not a claim that prompts
or existing Blender/Unity MCP tools cannot construct the same software.

## ADR-001: local capability engine

Use a deterministic Python kernel with versioned JSON contracts, subprocess
adapters, and a separate native Unity Editor/runtime package. A portable Agent
Skill and optional stdio MCP bridge call the same kernel. No core operation
requires model credentials, a central server, or arbitrary model-generated code.
Generic editor control is existing prior art; reusable contracts, invariants,
independent behavioral verification, and recoverable repairs are release-critical.

## Data and ownership

Frozen brief -> feature contracts -> validated manifest -> scene contract ->
dependency plan -> Blender outputs -> Unity native import -> actual behavior
evidence -> independently owned acceptance -> human/machine report.

The manifest is user-owned design. Scene contracts, run state, and artifact
registries are derived. Repairs cannot silently weaken original requirements.
Stages S0-S5 mean precheck, plan, model, audit/export, Unity build, verify.
Semantic IDs, hashes, seeds, tool versions, and explicit tolerances connect stages.

## Phase 0 interfaces

`Capability.execute(inputs, RunContext) -> Result` is implemented by a read-only
capability-descriptor validator. Context includes workspace, seed, time/output
budgets, retry limit, transaction ID, artifact registry, and lock path. Worker
locking, structured event logging, cancellation, and OS isolation arrive in Phase 1.
Network permission and claims of isolation are denied in this initial context.

`BaselineRunner.run(task, arm, seed)` and `AcceptanceEvaluator.grade(request)`
define independent interfaces. The unavailable evaluator returns BLOCKED/3;
it never assigns a passing grade. No benchmark execution is implemented yet.

## Versions and compatibility

Engine package: 0.0.1. Public contract/schema major: 1. Capability IDs end in a
versioned namespace such as `.v1`; descriptor versions use MAJOR.MINOR.PATCH.
Breaking changes require a new contract major and explicit reversible migration;
there are no previous persisted contracts to migrate in Phase 0.

Local application targets established during planning: Blender 5.2.2 LTS and
Unity 6000.6.3f1. Installed template metadata declares URP 17.6.0, Input System
1.19.0, and Test Framework 1.8.0. Installation presence is not integration proof.
Original blueprint baseline versions are not silently advertised as tested.

## Current capability boundary through Phase 10

The engine implements bounded static Blender assets, supplied base-color/normal
PNG transport, managed Unity import, the survival arena, robot rig animation,
sprite baking/import, scoped repair/recovery, worker roles, knowledge routing and
a read-only stdio MCP server. Each registered capability retains its own input,
tool, review and evidence requirements. Broad production authoring, an untrusted
OS sandbox, profiling and comparative benchmark execution remain unavailable;
registered future commands return explicit NOT_RUN results. The numbered phase
sections below record the architecture at those historical milestones.

Planning publishes a canonical `polyforge.lock.json` containing the manifest,
input hashes, seed, configuration, engine/Python identity, tool identities and
static package observations. Unprobed versions remain explicit. Owned artifact
records bind actual confined bytes to project/run/stage identity, upstream
hashes and validator status. A hash check alone does not establish native or
behavioral acceptance. Interrupted publication preserves the prior owned lock
and can recover only recognized previous/pending bytes.

Worker context freezes original task/brief, selected knowledge, probe evidence,
risks, approvals and engine-owned scope. Operation intents additionally bind the
actual dispatched input digest. Resuming an existing plan preserves that context;
new probe observations do not relabel earlier work. Job deadlines and declared
RAM/disk availability floors apply to native and inspector execution. A resource
loss cancels the operation and prevents a passing result even if its executor
ignores cancellation. Native Windows workers also retain Job Object memory caps.
Read-only OS adapter capacity metadata is separate from GPU execution support;
admission reports conservative single-worker CPU limits and explicit degradation.

## Phase 1 runtime

Config is bounded TOML with explicit executable overrides and default-denied
network/outside-root/untrusted settings. Doctor prefers installed application
roots over PATH (the generic Unity CLI can be unrelated to the Editor), probes
versions without opening projects, records limits/hardware/provenance, and writes
a structured report even when tools are missing. License and rendering readiness
remain independently NOT_RUN. Optional project checks are static known-file reads.

Each run has a durable append-only sequence of complete state snapshots plus an
atomic state.json cache. A killed cache write is recovered from events; incomplete
final event bytes are ignored until explicit recovery. Stage success requires
real nonempty evidence. Attempts, ownership locks and crash recovery are bounded.
State recovery is a library operation; CLI producer retry scheduling remains
unavailable until actual build stages exist. Manifest validation is implemented
in Phase 2.

Trusted workers use allowlisted binaries and owned process trees. Windows launches
suspend before job assignment and resume only after limits are set. Project locks
live at one physical project path so nested workspace roots cannot admit two Unity
workers. These resource/cleanup controls do not claim filesystem/network isolation.

API references: [Python subprocess](https://docs.python.org/3.11/library/subprocess.html),
[Windows Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects),
[Unity Editor arguments](https://docs.unity3d.com/6000.6/Documentation/Manual/EditorCommandLineArguments.html).

## ADR-002: deterministic contracts and planning

Validate shape, bounded finite JSON, unique IDs, source paths, references and DAGs
before publication. User-owned manifests are serialized canonically; derived
contracts preserve semantic IDs and raw brief hashes. Future feature declarations
are separate from the executable capability catalog. Every known future producer
is BLOCKED, unknown producers UNSUPPORTED, and acceptance remains DEVELOPMENT_ONLY.

Task fingerprints include only relevant local inputs plus upstream fingerprints.
Geometry contracts do not depend on global appearance. Material/texture edits
invalidate appearance, audit and import, preserving mesh/export and runtime-code
hashes. Rig animation edits invalidate dependent sprite bakes. Execution workers
must add actual tool fingerprints before their cache records become eligible.
Current planner tasks have NOT_RUN execution and unmeasured duration estimates.
An unchanged input is never sufficient evidence of completed output.

Scenario validation and handoff invariants are pure libraries, separate from
AcceptanceEvaluator. Synthetic report PASS means payload agreement only;
application_execution remains NOT_RUN. No hidden rubric is created or amended
by the compiler. See [manifest rules](manifests.md).

## Phase 4 interchange boundary

Static S3 rendering/export uses reviewed Blender code and independent host-side
PNG/sidecar validators. Source copies, measured geometry, FBX paths, metadata and
artifact hashes form a replayable binding set. Blender's own FBX importer validates
source-side roundtrip only. Unity/native physics and artistic review retain their
separate NOT_RUN/REVIEW statuses. Original source hashes are checked before saved
source audits, while Blender user configuration/cache paths stay under the run's
temporary directory. These controls preserve TRUSTED_LOCAL disclosure.

See [audit and export contracts](audit-export.md) for bounds, geometry taxonomy,
camera/renderer settings, material scope and the pending Unity import gate.

## Phase 6 runtime and verification

The bounded arena has a separate native scene and test assemblies. Runtime
primitives accept injected input, while production reads the pinned Input System.
Restart edges are queued after input updates and consumed once by fixed simulation.
The public development suite observes actual transforms, health and state through
real PlayMode frames. Python validates identity/structure before behavior scoring;
malformed mutants cannot be inverted into successful mutation detection.

Loaded scene identity, seed, actors and spawns must match the compiled request.
Frozen FBX identities are checked separately. Each declared enemy must patrol.
Immutable run bundles include source identities, an editable native archive,
process logs, XML, scenario observations and a development feature trace.
Package upgrades require hash-verified prior bytes before replacing owned code.
Modified user code is preserved; full crash/reimport transaction recovery remains
Phase 9. Manual play, standalone smoke, profiling and evaluator qualification
are distinct outcomes. See [the arena guide](arena.md).
